let currentTheme = 'dark';
        function toggleTheme() {
            currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
            if (currentTheme === 'light') {
                document.body.classList.add('light-mode');
                document.getElementById('btn-theme').innerText = '🌙';
            } else {
                document.body.classList.remove('light-mode');
                document.getElementById('btn-theme').innerText = '☀️';
            }
        }

        /* =====================================================
           COLLAPSIBLE SECTIONS
           ===================================================== */
        function toggleSection(id) {
            const sec = document.getElementById(id);
            if (!sec) return;
            sec.classList.toggle('collapsed');
        }

        function collapseAll() {
            const sections = document.querySelectorAll('.section[id]');
            const anyOpen = Array.from(sections).some(s => !s.classList.contains('collapsed'));
            sections.forEach(s => {
                if (anyOpen) s.classList.add('collapsed');
                else s.classList.remove('collapsed');
            });
        }

        /* =====================================================
           PROGRESS BAR
           ===================================================== */
        function setProgress(pct) {
            const bar = document.getElementById('nav-progress-bar');
            if (bar) bar.style.width = Math.min(100, Math.max(0, pct)) + '%';
        }
        function resetProgress() { setProgress(0); }

        /* =====================================================
           STEP WIZARD
           ===================================================== */
        function updateWizard(step) {
            // step: 0=idle, 1=A selected, 2=B+graph, 3=animating, 4=done
            const steps = [1, 2, 3, 4];
            const lines = [1, 2, 3];
            steps.forEach(s => {
                const el = document.getElementById('wiz-' + s);
                if (!el) return;
                el.classList.remove('active', 'done');
                if (s < step) el.classList.add('done');
                else if (s === step) el.classList.add('active');
            });
            lines.forEach(l => {
                const el = document.getElementById('wiz-line-' + l);
                if (!el) return;
                el.classList.toggle('done', l < step);
            });
        }

        /* =====================================================
           SIDEBAR RESIZE
           ===================================================== */
        (function initSidebarResize() {
            const handle = document.getElementById('sidebar-resize');
            const sidebar = document.getElementById('sidebar');
            if (!handle || !sidebar) return;
            let startX = 0, startW = 0, dragging = false;
            handle.addEventListener('mousedown', e => {
                dragging = true;
                startX = e.clientX;
                startW = sidebar.offsetWidth;
                handle.classList.add('dragging');
                document.body.style.cursor = 'col-resize';
                document.body.style.userSelect = 'none';
                e.preventDefault();
            });
            document.addEventListener('mousemove', e => {
                if (!dragging) return;
                const newW = Math.min(480, Math.max(240, startW + (e.clientX - startX)));
                sidebar.style.width = newW + 'px';
                sidebar.style.minWidth = newW + 'px';
            });
            document.addEventListener('mouseup', () => {
                if (!dragging) return;
                dragging = false;
                handle.classList.remove('dragging');
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
            });
        })();

        /* =====================================================
           KEYBOARD SHORTCUTS
           ===================================================== */
        document.addEventListener('keydown', e => {
            const tag = document.activeElement.tagName;
            if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
            switch (e.key) {
                case ' ':
                    e.preventDefault();
                    startVisualizer();
                    break;
                case 'r':
                case 'R':
                    resetVisualizer();
                    break;
                case '1':
                    if (!isAnimating) setMode('single');
                    break;
                case '2':
                    if (!isAnimating) setMode('vs');
                    break;
                case 'Escape':
                    // Close sidebar on mobile
                    const sb = document.getElementById('sidebar');
                    const ov = document.getElementById('sidebar-overlay');
                    const btn = document.getElementById('menu-toggle');
                    if (sb && sb.classList.contains('open')) {
                        sb.classList.remove('open');
                        ov.classList.remove('show');
                        if (btn) btn.textContent = '☰';
                    }
                    break;
            }
        });

        /* =====================================================
           MOBILE SWIPE GESTURE (close sidebar on swipe-left)
           ===================================================== */
        (function initSwipe() {
            let touchStartX = 0, touchStartY = 0;
            document.addEventListener('touchstart', e => {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
            }, { passive: true });
            document.addEventListener('touchend', e => {
                const dx = e.changedTouches[0].clientX - touchStartX;
                const dy = e.changedTouches[0].clientY - touchStartY;
                // Swipe left from sidebar: close
                if (dx < -60 && Math.abs(dy) < 60) {
                    const sb = document.getElementById('sidebar');
                    const ov = document.getElementById('sidebar-overlay');
                    const btn = document.getElementById('menu-toggle');
                    if (sb && sb.classList.contains('open')) {
                        sb.classList.remove('open');
                        ov.classList.remove('show');
                        if (btn) btn.textContent = '☰';
                    }
                }
                // Swipe right from left edge: open
                if (dx > 60 && Math.abs(dy) < 60 && touchStartX < 30) {
                    const sb = document.getElementById('sidebar');
                    const ov = document.getElementById('sidebar-overlay');
                    const btn = document.getElementById('menu-toggle');
                    if (sb && !sb.classList.contains('open')) {
                        sb.classList.add('open');
                        ov.classList.add('show');
                        if (btn) btn.textContent = '✕';
                    }
                }
            }, { passive: true });
        })();

        /* =====================================================
           COORDINATE DISPLAY ON MAP HOVER
           ===================================================== */
        function initCoordDisplay() {
            const coordEl = document.getElementById('coord-display');
            if (!coordEl) return;
            function attachCoordListener(map) {
                if (!map) return;
                map.on('mousemove', e => {
                    const lat = e.latlng.lat.toFixed(5);
                    const lng = e.latlng.lng.toFixed(5);
                    coordEl.textContent = `🌐 ${lat}°N, ${lng}°E`;
                });
                map.on('mouseout', () => {
                    coordEl.textContent = '🌐 —°, —°';
                });
            }
            // Will be called after maps init
            window._attachCoordToMaps = attachCoordListener;
        }
        initCoordDisplay();

        /* =====================================================
           STATE
           ===================================================== */
        let mapSingle, mapLeft, mapRight;
        let activeLayersSingle = [], activeLayersLeft = [], activeLayersRight = [];
        let markersSingle = {}, markersLeft = {}, markersRight = {};
        let polylinesSingle = {}, polylinesLeft = {}, polylinesRight = {};
        let weightMarkersSingle = {}, weightMarkersLeft = {}, weightMarkersRight = {};

        let tileSingle = null, tileLeft = null, tileRight = null;
        let edgeGeometries = {}; // key: "u-v", value: array of latlngs [lat, lng] snapped to roads

        const MAP_STYLES = {
            'osm-dark': {
                url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
                options: {
                    attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
                    maxZoom: 22,
                    maxNativeZoom: 20
                }
            },
            'osm-standard': {
                url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                options: {
                    attribution: '&copy; OpenStreetMap contributors',
                    maxZoom: 22,
                    maxNativeZoom: 19
                }
            },
            'osm-satellite': {
                url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
                options: {
                    attribution: 'Tiles &copy; Esri &mdash; Source: Esri',
                    maxZoom: 22,
                    maxNativeZoom: 18
                }
            },
            'osm-terrain': {
                url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
                options: {
                    attribution: 'Map data: &copy; OSM contributors, SRTM | style: &copy; OpenTopoMap',
                    maxZoom: 22,
                    maxNativeZoom: 17
                }
            }
        };

        let nodeCoordinates = {};
        let graph = {};
        let edges = [];

        let startNodeCoords = null;
        let endNodeCoords = null;
        let clickCount = 0;

        let activeMode = 'single';
        let selectedAlgo = 'dijkstra';
        let isAnimating = false;
        let animationDelay = 300;
        let currentAnimationId = 0;

        // VS state
        let vsStatsData = {
            a: { visited: 0, cost: '—' },
            b: { visited: 0, cost: '—' }
        };

        let nodeStreetNames = {};
        let pathPolylineSingle = null;
        let pathPolylineLeft = null;
        let pathPolylineRight = null;

        /* =====================================================
           UTILITY
           ===================================================== */
        function getEdgeKey(u, v) {
            return [u, v].sort().join('-');
        }

        // Snap edge coordinates to real streets using OSRM Routing API (Google Maps style)
        async function fetchEdgeGeometry(u, v) {
            const cU = nodeCoordinates[u];
            const cV = nodeCoordinates[v];
            if (!cU || !cV) return [cU, cV];

            // Eğer deniz geçişi ise, OSRM'den yol tarifi çekme (köprülerden dolanır), direkt çizgi çiz.
            if (u.startsWith('Sea') || v.startsWith('Sea') || u.startsWith('Port') || v.startsWith('Port')) {
                return [cU, cV];
            }

            const url = `https://router.project-osrm.org/route/v1/driving/${cU[1]},${cU[0]};${cV[1]},${cV[0]}?overview=full&geometries=geojson`;
            try {
                const res = await fetch(url);
                const data = await res.json();
                if (data.code === 'Ok' && data.routes && data.routes[0]) {
                    let coords = data.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
                    coords = removeRouteLoops(coords);
                    return coords;
                }
            } catch (e) {
                console.error("OSRM Routing error: ", e);
            }
            return [cU, cV]; // Fallback to straight line if offline
        }

        async function fetchAllEdgeGeometries() {
            await fetchAllNodeStreetNames();
            renderAllGraphs();
            drawSelectedRoutePreview();
        }

        function updatePolylineGeometry(key, geom) {
            if (polylinesSingle[key]) polylinesSingle[key].setLatLngs(geom);
            if (polylinesLeft[key]) polylinesLeft[key].setLatLngs(geom);
            if (polylinesRight[key]) polylinesRight[key].setLatLngs(geom);

            // Reposition the traffic weight badges dynamically to center of the real street path
            const midIndex = Math.floor(geom.length / 2);
            const midCoord = geom[midIndex];
            if (midCoord) {
                if (weightMarkersSingle[key]) weightMarkersSingle[key].setLatLng([midCoord[0], midCoord[1]]);
                if (weightMarkersLeft[key]) weightMarkersLeft[key].setLatLng([midCoord[0], midCoord[1]]);
                if (weightMarkersRight[key]) weightMarkersRight[key].setLatLng([midCoord[0], midCoord[1]]);
            }
        }

        function getGeographicalDistance(coordsA, coordsB) {
            const R = 6371;
            const dLat = (coordsB[0] - coordsA[0]) * Math.PI / 180;
            const dLon = (coordsB[1] - coordsA[1]) * Math.PI / 180;
            const a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(coordsA[0] * Math.PI / 180) * Math.cos(coordsB[0] * Math.PI / 180) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        }

        // A* için kuryenin müşteriye olan kuş uçuşu mahalle mesafesi sezgiseli (admissible & consistent)
        function getHeuristicDistance(nodeKey, targetKey) {
            if (nodeKey === targetKey) return 0;
            const nc = nodeCoordinates[nodeKey];
            const tc = nodeCoordinates[targetKey];
            if (!nc || !tc) return 0;
            // Eşik katsayısı olarak yol oluşturmadaki minimum katsayıyı (40) kullanıyoruz.
            // Bu sayede sezgisel değer her zaman gerçek yol maliyetinden küçük veya eşit (admissible) olur.
            return getGeographicalDistance(nc, tc) * 40;
        }

        /* =====================================================
           DYNAMIC 3-PATH ROUTE GENERATOR
           ===================================================== */
        const PORTS = {
            istanbul: {
                east: [
                    { name: "Üsküdar İskelesi", coords: [41.0270, 29.0152] },
                    { name: "Kadıköy İskelesi", coords: [40.9912, 29.0224] },
                    { name: "Harem İskelesi", coords: [41.0112, 29.0118] },
                    { name: "Bostancı İskelesi", coords: [40.9521, 29.0945] }
                ],
                west: [
                    { name: "Beşiktaş İskelesi", coords: [41.0415, 29.0068] },
                    { name: "Karaköy İskelesi", coords: [41.0222, 28.9754] },
                    { name: "Eminönü İskelesi", coords: [41.0182, 28.9734] },
                    { name: "Kabataş İskelesi", coords: [41.0335, 28.9930] },
                    { name: "Yenikapı İskelesi", coords: [41.0022, 28.9525] }
                ]
            },
            izmir: {
                north: [
                    { name: "Karşıyaka İskelesi", coords: [38.4556, 27.1215] },
                    { name: "Bostanlı İskelesi", coords: [38.4533, 27.0964] }
                ],
                south: [
                    { name: "Alsancak İskelesi", coords: [38.4395, 27.1425] },
                    { name: "Pasaport İskelesi", coords: [38.4287, 27.1332] },
                    { name: "Konak İskelesi", coords: [38.4188, 27.1278] },
                    { name: "Göztepe İskelesi", coords: [38.4011, 27.0815] },
                    { name: "Üçkuyular İskelesi", coords: [38.4045, 27.0655] }
                ]
            }
        };

        let portAName = 'Liman A';
        let portBName = 'Liman B';

        function detectSeaCrossing(latA, lngA, latB, lngB) {
            const dist = getGeographicalDistance([latA, lngA], [latB, lngB]);
            // Şehir içi geçiş mesafesi kontrolü (60 km'den fazlaysa deniz hattı kurma)
            if (dist > 60) return null;

            // İstanbul kontrolü
            let closestEastIst = null, minDistEastIst = Infinity;
            PORTS.istanbul.east.forEach(p => {
                const d = getGeographicalDistance([latA, lngA], p.coords);
                if (d < minDistEastIst) { minDistEastIst = d; closestEastIst = p; }
            });

            let closestWestIst = null, minDistWestIst = Infinity;
            PORTS.istanbul.west.forEach(p => {
                const d = getGeographicalDistance([latA, lngA], p.coords);
                if (d < minDistWestIst) { minDistWestIst = d; closestWestIst = p; }
            });
            const aSideIst = minDistEastIst < minDistWestIst ? 'east' : 'west';
            const aDistToIst = Math.min(minDistEastIst, minDistWestIst);

            let closestEastIstB = null, minDistEastIstB = Infinity;
            PORTS.istanbul.east.forEach(p => {
                const d = getGeographicalDistance([latB, lngB], p.coords);
                if (d < minDistEastIstB) { minDistEastIstB = d; closestEastIstB = p; }
            });

            let closestWestIstB = null, minDistWestIstB = Infinity;
            PORTS.istanbul.west.forEach(p => {
                const d = getGeographicalDistance([latB, lngB], p.coords);
                if (d < minDistWestIstB) { minDistWestIstB = d; closestWestIstB = p; }
            });
            const bSideIst = minDistEastIstB < minDistWestIstB ? 'east' : 'west';

            if (aDistToIst < 25 && aSideIst !== bSideIst) {
                return {
                    portA: aSideIst === 'east' ? closestEastIst : closestWestIst,
                    portB: bSideIst === 'east' ? closestEastIstB : closestWestIstB,
                    city: 'istanbul'
                };
            }

            // İzmir kontrolü
            let closestNorthIzm = null, minDistNorthIzm = Infinity;
            PORTS.izmir.north.forEach(p => {
                const d = getGeographicalDistance([latA, lngA], p.coords);
                if (d < minDistNorthIzm) { minDistNorthIzm = d; closestNorthIzm = p; }
            });

            let closestSouthIzm = null, minDistSouthIzm = Infinity;
            PORTS.izmir.south.forEach(p => {
                const d = getGeographicalDistance([latA, lngA], p.coords);
                if (d < minDistSouthIzm) { minDistSouthIzm = d; closestSouthIzm = p; }
            });
            const aSideIzm = minDistNorthIzm < minDistSouthIzm ? 'north' : 'south';
            const aDistToIzm = Math.min(minDistNorthIzm, minDistSouthIzm);

            let closestNorthIzmB = null, minDistNorthIzmB = Infinity;
            PORTS.izmir.north.forEach(p => {
                const d = getGeographicalDistance([latB, lngB], p.coords);
                if (d < minDistNorthIzmB) { minDistNorthIzmB = d; closestNorthIzmB = p; }
            });

            let closestSouthIzmB = null, minDistSouthIzmB = Infinity;
            PORTS.izmir.south.forEach(p => {
                const d = getGeographicalDistance([latB, lngB], p.coords);
                if (d < minDistSouthIzmB) { minDistSouthIzmB = d; closestSouthIzmB = p; }
            });
            const bSideIzm = minDistNorthIzmB < minDistSouthIzmB ? 'north' : 'south';

            if (aDistToIzm < 25 && aSideIzm !== bSideIzm) {
                return {
                    portA: aSideIzm === 'north' ? closestNorthIzm : closestSouthIzm,
                    portB: bSideIzm === 'north' ? closestNorthIzmB : closestSouthIzmB,
                    city: 'izmir'
                };
            }

            return null;
        }

        function removeRouteLoops(coords) {
            let cleaned = [...coords];

            // Helper to build cumulative distances
            function buildCumDist(arr) {
                const dists = [0];
                for (let k = 1; k < arr.length; k++) {
                    dists.push(dists[k - 1] + getGeographicalDistance(arr[k - 1], arr[k]) * 1000);
                }
                return dists;
            }

            let cumDist = buildCumDist(cleaned);
            let i = 0;
            while (i < cleaned.length - 3) {
                let bestJ = -1;
                for (let j = cleaned.length - 1; j > i + 3; j--) {
                    const straightDist = getGeographicalDistance(cleaned[i], cleaned[j]) * 1000;
                    const routeDist = cumDist[j] - cumDist[i];

                    if (straightDist < 100 && routeDist > 120 && routeDist > 1.8 * straightDist) {
                        bestJ = j;
                        break;
                    }
                }

                if (bestJ !== -1) {
                    cleaned.splice(i + 1, bestJ - i - 1);
                    cumDist = buildCumDist(cleaned); // Rebuild cumulative distances after splice
                } else {
                    i++;
                }
            }
            return cleaned;
        }

        async function fetchOSRMRouteAndSteps(startCoords, endCoords, waypointCoords = null) {
            let points = [startCoords];
            if (waypointCoords) {
                points.push(waypointCoords);
            }
            points.push(endCoords);

            const coordString = points.map(p => `${p[1]},${p[0]}`).join(';');
            const url = `https://router.project-osrm.org/route/v1/driving/${coordString}?overview=full&geometries=geojson&steps=true`;
            try {
                const res = await fetch(url);
                const data = await res.json();
                if (data.code === 'Ok' && data.routes && data.routes[0]) {
                    const route = data.routes[0];
                    let coords = route.geometry.coordinates.map(c => [c[1], c[0]]);

                    let turns = [];
                    if (route.legs) {
                        route.legs.forEach(leg => {
                            if (leg.steps) {
                                leg.steps.forEach(step => {
                                    if (step.maneuver && step.maneuver.location) {
                                        const loc = [step.maneuver.location[1], step.maneuver.location[0]];
                                        const streetName = step.name || "İsimsiz Yol";
                                        turns.push({ coords: loc, streetName });
                                    }
                                });
                            }
                        });
                    }

                    // Clean up detours/loops
                    coords = removeRouteLoops(coords);

                    // Filter turns to only include those close to our cleaned route coordinates
                    turns = turns.filter(t => {
                        let minD = Infinity;
                        for (let c = 0; c < coords.length; c++) {
                            const d = getGeographicalDistance(t.coords, coords[c]) * 1000;
                            if (d < minD) minD = d;
                        }
                        return minD < 40; // Only keep turns near the cleaned route
                    });

                    return { coords, turns };
                }
            } catch (e) {
                console.error("OSRM Route & Steps fetch error: ", e);
            }

            // Fallback
            const coords = [];
            const steps = 15;
            for (let i = 0; i <= steps; i++) {
                const t = i / steps;
                coords.push([
                    startCoords[0] + t * (endCoords[0] - startCoords[0]),
                    startCoords[1] + t * (endCoords[1] - startCoords[1])
                ]);
            }
            const turns = [
                { coords: startCoords, streetName: "Başlangıç" },
                { coords: endCoords, streetName: "Bitiş" }
            ];
            return { coords, turns };
        }

        function extractNodesFromTurns(coords, turns, maxNodes, prefix, startNum = 1) {
            const L = coords.length;
            if (L < 3 || maxNodes < 1) return [];

            // Rota boyunca kümülatif mesafeyi hesapla
            const cumDist = [0];
            for (let i = 1; i < L; i++) {
                cumDist.push(cumDist[i - 1] + getGeographicalDistance(coords[i - 1], coords[i]));
            }
            const totalDist = cumDist[L - 1];

            const nodes = [];
            for (let n = 1; n <= maxNodes; n++) {
                // Her düğümü toplam rota mesafesinin eşit kesirinde yerleştir
                const targetDist = totalDist * (n / (maxNodes + 1));

                // İkili arama ile en yakın koordinat indeksini bul
                let lo = 0, hi = L - 1;
                while (lo < hi) {
                    const mid = (lo + hi) >> 1;
                    if (cumDist[mid] < targetDist) lo = mid + 1;
                    else hi = mid;
                }
                // Uç noktalardan güvenli uzaklıkta tut
                const idx = Math.max(2, Math.min(L - 3, lo));

                const key = `${prefix}${startNum + n - 1}`;
                nodeCoordinates[key] = coords[idx];

                // En yakın manevra noktasının sokak adını ata
                let streetName = 'Ara Sokak';
                let minD = Infinity;
                turns.forEach(t => {
                    const d = getGeographicalDistance(coords[idx], t.coords);
                    if (d < minD) { minD = d; streetName = t.streetName || 'Ara Sokak'; }
                });
                nodeStreetNames[key] = streetName;
                nodes.push({ key, index: idx });
            }

            return nodes;
        }

        function createEdgesAndGeometries(prefix, startNode, endNode, nodes, coords, trafficFactor) {
            const L = coords.length;

            if (nodes.length === 0) {
                const segDist = getSegmentDistance(coords);
                const weight = Math.max(5, Math.round(segDist * 40 * trafficFactor));
                edges.push({ u: startNode, v: endNode, w: weight });
                edgeGeometries[getEdgeKey(startNode, endNode)] = coords;
                return;
            }

            // Connect startNode to first node
            const firstNode = nodes[0];
            const geomFirst = coords.slice(0, firstNode.index + 1);
            const distFirst = getSegmentDistance(geomFirst);
            const wFirst = Math.max(5, Math.round(distFirst * 40 * trafficFactor));
            edges.push({ u: startNode, v: firstNode.key, w: wFirst });
            edgeGeometries[getEdgeKey(startNode, firstNode.key)] = geomFirst;

            // Connect intermediate nodes
            for (let i = 0; i < nodes.length - 1; i++) {
                const u = nodes[i];
                const v = nodes[i + 1];
                const geomMid = coords.slice(u.index, v.index + 1);
                const distMid = getSegmentDistance(geomMid);
                const wMid = Math.max(5, Math.round(distMid * 40 * trafficFactor));
                edges.push({ u: u.key, v: v.key, w: wMid });
                edgeGeometries[getEdgeKey(u.key, v.key)] = geomMid;
            }

            // Connect last node to endNode
            const lastNode = nodes[nodes.length - 1];
            const geomLast = coords.slice(lastNode.index);
            const distLast = getSegmentDistance(geomLast);
            const wLast = Math.max(5, Math.round(distLast * 40 * trafficFactor));
            edges.push({ u: lastNode.key, v: endNode, w: wLast });
            edgeGeometries[getEdgeKey(lastNode.key, endNode)] = geomLast;
        }

        function getSegmentDistance(coords) {
            let dist = 0;
            for (let i = 0; i < coords.length - 1; i++) {
                dist += getGeographicalDistance(coords[i], coords[i + 1]);
            }
            return dist;
        }

        function getSeaGeom(coordsA, coordsB, offsetMultiplier) {
            const latDiff = coordsB[0] - coordsA[0];
            const lngDiff = coordsB[1] - coordsA[1];
            const dist = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);
            const offsetMag = dist * 0.15;

            let px = 0, py = 0;
            if (dist > 0) {
                px = -lngDiff / dist;
                py = latDiff / dist;
            }

            const geom = [];
            const steps = 10;
            for (let i = 0; i <= steps; i++) {
                const t = i / steps;
                const baseLat = coordsA[0] + t * latDiff;
                const baseLng = coordsA[1] + t * lngDiff;
                const dome = Math.sin(t * Math.PI);
                geom.push([
                    baseLat + px * offsetMag * dome * offsetMultiplier,
                    baseLng + py * offsetMag * dome * offsetMultiplier
                ]);
            }
            return geom;
        }

        function connectSeaRoute(seaNode, portA, portB, geom, weight) {
            const midIndex = Math.floor(geom.length / 2);

            const geom1 = geom.slice(0, midIndex + 1);
            const geom2 = geom.slice(midIndex);

            edges.push({ u: portA, v: seaNode, w: Math.round(weight / 2) });
            edges.push({ u: seaNode, v: portB, w: Math.round(weight / 2) });

            edgeGeometries[getEdgeKey(portA, seaNode)] = geom1;
            edgeGeometries[getEdgeKey(seaNode, portB)] = geom2;
        }

        async function generateParallelRoutes(latA, lngA, latB, lngB) {
            nodeCoordinates = {};
            nodeCoordinates['A'] = [latA, lngA];
            nodeCoordinates['B'] = [latB, lngB];
            edges = [];
            edgeGeometries = {};
            nodeStreetNames = {};

            const crossing = detectSeaCrossing(latA, lngA, latB, lngB);

            if (crossing) {
                portAName = crossing.portA.name;
                portBName = crossing.portB.name;

                const latPortA = crossing.portA.coords[0];
                const lngPortA = crossing.portA.coords[1];
                const latPortB = crossing.portB.coords[0];
                const lngPortB = crossing.portB.coords[1];

                nodeCoordinates['PortA'] = [latPortA, lngPortA];
                nodeCoordinates['PortB'] = [latPortB, lngPortB];

                // Fetch land routes
                const { coords: landCoordsA, turns: turnsA } = await fetchOSRMRouteAndSteps([latA, lngA], [latPortA, lngPortA]);
                const { coords: landCoordsB, turns: turnsB } = await fetchOSRMRouteAndSteps([latPortB, lngPortB], [latB, lngB]);

                nodeStreetNames['A'] = turnsA[0] ? turnsA[0].streetName : "Başlangıç";
                nodeStreetNames['B'] = turnsB[turnsB.length - 1] ? turnsB[turnsB.length - 1].streetName : "Bitiş";

                // Part 1: A to PortA
                const nodesC_Part1 = extractNodesFromTurns(landCoordsA, turnsA, 2, 'C', 1);
                const nodesS_Part1 = extractNodesFromTurns(landCoordsA, turnsA, 3, 'S', 1);
                const nodesE_Part1 = extractNodesFromTurns(landCoordsA, turnsA, 2, 'E', 1);

                createEdgesAndGeometries('C', 'A', 'PortA', nodesC_Part1, landCoordsA, 1.8);
                createEdgesAndGeometries('S', 'A', 'PortA', nodesS_Part1, landCoordsA, 1.0);
                createEdgesAndGeometries('E', 'A', 'PortA', nodesE_Part1, landCoordsA, 1.3);

                // Part 2: PortA to PortB (Sea routes)
                const seaCoords1 = getSeaGeom([latPortA, lngPortA], [latPortB, lngPortB], 0);
                const seaCoords2 = getSeaGeom([latPortA, lngPortA], [latPortB, lngPortB], 1);
                const seaCoords3 = getSeaGeom([latPortA, lngPortA], [latPortB, lngPortB], -1);

                nodeCoordinates['Sea1'] = seaCoords1[Math.floor(seaCoords1.length / 2)];
                nodeCoordinates['Sea2'] = seaCoords2[Math.floor(seaCoords2.length / 2)];
                nodeCoordinates['Sea3'] = seaCoords3[Math.floor(seaCoords3.length / 2)];

                connectSeaRoute('Sea1', 'PortA', 'PortB', seaCoords1, 25);
                connectSeaRoute('Sea2', 'PortA', 'PortB', seaCoords2, 12);
                connectSeaRoute('Sea3', 'PortA', 'PortB', seaCoords3, 35);

                // Part 3: PortB to B
                const nodesC_Part3 = extractNodesFromTurns(landCoordsB, turnsB, 2, 'C', 3);
                const nodesS_Part3 = extractNodesFromTurns(landCoordsB, turnsB, 3, 'S', 4);
                const nodesE_Part3 = extractNodesFromTurns(landCoordsB, turnsB, 2, 'E', 3);

                createEdgesAndGeometries('C', 'PortB', 'B', nodesC_Part3, landCoordsB, 1.8);
                createEdgesAndGeometries('S', 'PortB', 'B', nodesS_Part3, landCoordsB, 1.0);
                createEdgesAndGeometries('E', 'PortB', 'B', nodesE_Part3, landCoordsB, 1.3);

            } else {
                const latDiff = latB - latA;
                const lngDiff = lngB - lngA;
                const dist = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);
                const offset = Math.min(dist * 0.15, 0.002);

                let px = 0, py = 0;
                if (dist > 0) {
                    px = -lngDiff / dist;
                    py = latDiff / dist;
                }

                const midLat = (latA + latB) / 2;
                const midLng = (lngA + lngB) / 2;

                const waypoint1 = [midLat + px * offset, midLng + py * offset];
                const waypoint2 = [midLat - px * offset, midLng - py * offset];

                // Fetch 3 routes
                const route1 = await fetchOSRMRouteAndSteps([latA, lngA], [latB, lngB]);
                const route2 = await fetchOSRMRouteAndSteps([latA, lngA], [latB, lngB], waypoint1);
                const route3 = await fetchOSRMRouteAndSteps([latA, lngA], [latB, lngB], waypoint2);

                // Cache start and end street names from Route 1
                nodeStreetNames['A'] = route1.turns[0] ? route1.turns[0].streetName : "Başlangıç";
                nodeStreetNames['B'] = route1.turns[route1.turns.length - 1] ? route1.turns[route1.turns.length - 1].streetName : "Bitiş";

                // Sample intermediate nodes
                const nodesC = extractNodesFromTurns(route1.coords, route1.turns, 2, 'C', 1);
                const nodesS = extractNodesFromTurns(route2.coords, route2.turns, 4, 'S', 1);
                const nodesE = extractNodesFromTurns(route3.coords, route3.turns, 3, 'E', 1);

                // Build edges & geometries
                createEdgesAndGeometries('C', 'A', 'B', nodesC, route1.coords, 1.8);
                createEdgesAndGeometries('S', 'A', 'B', nodesS, route2.coords, 1.0);
                createEdgesAndGeometries('E', 'A', 'B', nodesE, route3.coords, 1.3);
            }

            graph = {};
            const allKeys = Object.keys(nodeCoordinates);
            const envNow = getSolarEnvParams(false);
            allKeys.forEach(k => graph[k] = []);
            edges.forEach(edge => {
                graph[edge.u].push({ target: edge.v, weight: edge.w, solarWeight: solarCost(edge.w, envNow) });
                graph[edge.v].push({ target: edge.u, weight: edge.w, solarWeight: solarCost(edge.w, envNow) });
            });
        }

        /* =====================================================
           LEAFLET ICON BUILDERS
           ===================================================== */
        function createCustomIcon(label, status = 'default', colorVar = 'var(--accent-cyan)') {
            let glowClass = '';
            let iconGlyph = ''; // Default is empty dot

            if (status === 'start') {
                colorVar = 'var(--accent-cyan)';
                iconGlyph = '🛸';
            } else if (status === 'end') {
                colorVar = 'var(--accent-green)';
                iconGlyph = '📦';
            } else if (status === 'visited') {
                glowClass = 'node-pulse-active';
            } else if (status === 'path') {
                colorVar = 'var(--accent-green)';
                glowClass = 'node-pulse-path';
            }

            // Custom glyphs for Ports and Sea lanes
            if (label.includes('Limanı') || label.includes('Port') || label.includes('İskelesi')) {
                iconGlyph = '⚓';
                colorVar = 'var(--accent-blue)';
            } else if (label.includes('Deniz Hattı') || label.includes('Sea')) {
                iconGlyph = '🚢';
                colorVar = 'var(--accent-cyan)';
            }

            return L.divIcon({
                className: 'custom-node-icon',
                html: `<div class="node-marker" style="--node-color: ${colorVar}">
                    <div class="node-pulse ${glowClass}"></div>
                    <div class="node-dot" style="display: flex; align-items: center; justify-content: center;">${iconGlyph}</div>
                    <div class="node-label">${label}</div>
                </div>`,
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            });
        }

        function createWeightIcon(weight) {
            return L.divIcon({
                className: 'edge-weight-badge',
                html: `<span>${weight}</span>`,
                iconSize: [28, 18],
                iconAnchor: [14, 9]
            });
        }

        /* Şu an taranmakta olan düğüm için parlak ikon */
        function createCurrentScanIcon(label) {
            return L.divIcon({
                className: 'custom-node-icon',
                html: `<div class="node-marker" style="--node-color: #f97316">
                    <div class="node-pulse node-scanning-pulse"></div>
                    <div class="node-dot node-scanning-dot" style="display: flex; align-items: center; justify-content: center;">⚡</div>
                    <div class="node-label" style="background:rgba(249,115,22,0.92); color:#fff; border-color:#f97316; font-weight:700; white-space:nowrap;">${label}</div>
                </div>`,
                iconSize: [28, 28],
                iconAnchor: [14, 14]
            });
        }
        async function snapToNearestRoad(lat, lng) {
            const url = `https://router.project-osrm.org/nearest/v1/driving/${lng},${lat}?number=1`;
            try {
                const res = await fetch(url);
                const data = await res.json();
                if (data.code === 'Ok' && data.waypoints && data.waypoints[0] && data.waypoints[0].location) {
                    const loc = data.waypoints[0].location;
                    return [loc[1], loc[0]]; // OSRM returns [lng, lat], we return [lat, lng]
                }
            } catch (e) {
                console.error("OSRM nearest snap error: ", e);
            }
            return [lat, lng];
        }

        async function fetchStreetName(key, lat, lng) {
            if (key.startsWith('Sea')) return;

            const cacheKey = `${lat.toFixed(5)},${lng.toFixed(5)}`;
            if (nodeStreetNames[cacheKey]) {
                nodeStreetNames[key] = nodeStreetNames[cacheKey];
                return;
            }

            const url = `https://router.project-osrm.org/nearest/v1/driving/${lng},${lat}?number=1`;
            try {
                const res = await fetch(url);
                const data = await res.json();
                if (data.code === 'Ok' && data.waypoints && data.waypoints[0]) {
                    let name = data.waypoints[0].name;
                    if (!name || name.trim() === "") {
                        name = "İsimsiz Yol";
                    }
                    nodeStreetNames[key] = name;
                    nodeStreetNames[cacheKey] = name;
                } else {
                    nodeStreetNames[key] = null;
                }
            } catch (e) {
                console.error("OSRM nearest error: ", e);
                nodeStreetNames[key] = null;
            }
        }

        async function fetchAllNodeStreetNames() {
            const promises = [];
            for (const key in nodeCoordinates) {
                const coords = nodeCoordinates[key];
                promises.push(fetchStreetName(key, coords[0], coords[1]));
            }
            await Promise.all(promises);
        }

        function getPathCoordinates(path) {
            let coords = [];
            for (let i = 0; i < path.length - 1; i++) {
                const u = path[i];
                const v = path[i + 1];
                const key = getEdgeKey(u, v);
                const geom = edgeGeometries[key] || [nodeCoordinates[u], nodeCoordinates[v]];
                if (i === 0) {
                    coords.push(...geom);
                } else {
                    coords.push(...geom.slice(1));
                }
            }
            return coords;
        }

        function clearHighlightedRoutes() {
            if (pathPolylineSingle && mapSingle) { mapSingle.removeLayer(pathPolylineSingle); pathPolylineSingle = null; }
            if (pathPolylineLeft && mapLeft) { mapLeft.removeLayer(pathPolylineLeft); pathPolylineLeft = null; }
            if (pathPolylineRight && mapRight) { mapRight.removeLayer(pathPolylineRight); pathPolylineRight = null; }
        }

        function drawSelectedRoutePreview() {
            if (isAnimating) return; // Animasyon esnasında önizlemeyi çizme

            clearHighlightedRoutes();

            if (!nodeCoordinates['A'] || !nodeCoordinates['B']) return;

            if (activeMode === 'single') {
                const result = runAlgo(selectedAlgo, 'A', 'B');
                if (result && result.success && result.path.length > 1) {
                    const coords = getPathCoordinates(result.path);
                    pathPolylineSingle = L.polyline(coords, {
                        color: 'var(--accent-green)',
                        weight: 8,
                        opacity: 0.6,
                        dashArray: '10, 10'
                    }).addTo(mapSingle);
                }
            } else {
                const algoLeft = document.getElementById('vs-algo-a').value;
                const algoRight = document.getElementById('vs-algo-b').value;

                const resultLeft = runAlgo(algoLeft, 'A', 'B', false);   // klasik
                if (resultLeft && resultLeft.success && resultLeft.path.length > 1) {
                    const coords = getPathCoordinates(resultLeft.path);
                    pathPolylineLeft = L.polyline(coords, {
                        color: '#ef4444',  // Kırmızı – Klasik Rota
                        weight: 8,
                        opacity: 0.6,
                        dashArray: '10, 10'
                    }).addTo(mapLeft);
                }

                const resultRight = runAlgo(algoRight, 'A', 'B', true);  // solar
                if (resultRight && resultRight.success && resultRight.path.length > 1) {
                    const coords = getPathCoordinates(resultRight.path);
                    pathPolylineRight = L.polyline(coords, {
                        color: 'var(--accent-green)',  // Yeşil – SOLARGRAF
                        weight: 8,
                        opacity: 0.6,
                        dashArray: '10, 10'
                    }).addTo(mapRight);
                }
            }
        }

        function getNodeLabel(key) {
            if (key === 'A') return `Kalkış Noktası (A)${nodeStreetNames['A'] ? ' – ' + nodeStreetNames['A'] : ''}`;
            if (key === 'B') return `Varış Noktası (B)${nodeStreetNames['B'] ? ' – ' + nodeStreetNames['B'] : ''}`;
            if (key === 'PortA') return portAName;
            if (key === 'PortB') return portBName;
            if (key === 'Sea1') return 'İHA Deniz Rotası';
            if (key === 'Sea2') return 'Hızlı İHA Hattı';
            if (key === 'Sea3') return 'Alternatif İHA Rotası';

            // Return fetched street name or fallback
            if (nodeStreetNames[key]) {
                return nodeStreetNames[key];
            }

            const fallbacks = {
                'C1': 'Ana Güzergah',
                'C2': 'Güzergah Bağlantısı',
                'C3': 'Bulvar Hattı',
                'C4': 'Bulvar Bağlantısı',
                'S1': 'İHA Ara Noktası',
                'S2': 'Geçiş Noktası',
                'S3': 'Ara Güzergah',
                'S4': 'Çıkış Noktası',
                'S5': 'Waypoint 5',
                'S6': 'Waypoint 6',
                'E1': 'Çevre Hattı Girişi',
                'E2': 'Yüksek İrtifa Yolu',
                'E3': 'Çevre Hattı Çıkışı',
                'E4': 'Kavşak Bağlantısı'
            };
            return fallbacks[key] || key;
        }

        /* =====================================================
           MAP SETUP
           ===================================================== */
        async function initMaps() {
            const initialStyle = MAP_STYLES['osm-dark'];

            // Kadıköy coordinates centered for neighborhood street view!
            mapSingle = L.map('map-single', { center: [40.9901, 29.0290], zoom: 16, minZoom: 1, maxZoom: 22, zoomControl: true });
            tileSingle = L.tileLayer(initialStyle.url, initialStyle.options).addTo(mapSingle);

            mapLeft = L.map('map-left', { center: [40.9901, 29.0290], zoom: 15.5, minZoom: 1, maxZoom: 22, zoomControl: false });
            tileLeft = L.tileLayer(initialStyle.url, initialStyle.options).addTo(mapLeft);

            mapRight = L.map('map-right', { center: [40.9901, 29.0290], zoom: 15.5, minZoom: 1, maxZoom: 22, zoomControl: false });
            tileRight = L.tileLayer(initialStyle.url, initialStyle.options).addTo(mapRight);

            // Sync VS maps
            let isSyncing = false;
            function syncMaps(source, target) {
                source.on('zoomend moveend', () => {
                    if (isSyncing) return;
                    isSyncing = true;
                    target.setView(source.getCenter(), source.getZoom(), { animate: false });
                    isSyncing = false;
                });
            }
            syncMaps(mapLeft, mapRight);
            syncMaps(mapRight, mapLeft);

            // Click handler
            async function handleMapClick(e) {
                if (isAnimating) return;
                const latlng = e.latlng;

                if (clickCount === 0) {
                    startNodeCoords = [latlng.lat, latlng.lng];
                    clickCount = 1;
                    clearAllMapLayers();
                    drawStartMarkerOnly(latlng.lat, latlng.lng);
                    updateStepInfo('Kalkış Noktası (A) seçildi. Şimdi Varış Noktası (B) seçmek için haritaya tıklayın.');
                    document.getElementById('canvas-label').textContent = '🛸 Varış Noktası (B) seçmek için haritaya tıklayın...';
                    updateWizard(1);
                    setProgress(15);
                    toast('📍 Kalkış Noktası (A) Seçildi!');
                    // Otomatik hava durumu eşitleme
                    fetchLiveWeather(latlng.lat, latlng.lng);
                } else {
                    endNodeCoords = [latlng.lat, latlng.lng];
                    clickCount = 0;

                    updateWizard(2);
                    setProgress(30);
                    toast('🛸 İHA güzergahları hesaplanıyor...');
                    await generateParallelRoutes(startNodeCoords[0], startNodeCoords[1], endNodeCoords[0], endNodeCoords[1]);
                    renderAllGraphs();
                    fitMapBounds();
                    setProgress(60);
                    await fetchAllEdgeGeometries();
                    setProgress(90);

                    updateStepInfo('3 alternatif İHA güzergahı çizildi. ▶ Başlat ile simülasyonu başlatın!');
                    document.getElementById('canvas-label').textContent = '🛸 Haritada tıkla ➔ 1.tık=Kalkış Noktası (A) | 2.tık=Varış Noktası (B) + 3 alternatif İHA güzergahı';
                    setTimeout(resetProgress, 800);
                    toast('🌿 3 alternatif yeşil lojistik güzergahı oluşturuldu!');
                }
            }

            mapSingle.on('click', handleMapClick);
            mapLeft.on('click', handleMapClick);
            mapRight.on('click', handleMapClick);

            // Attach coordinate display
            if (window._attachCoordToMaps) {
                window._attachCoordToMaps(mapSingle);
                window._attachCoordToMaps(mapLeft);
                window._attachCoordToMaps(mapRight);
            }

            // Sayfa açılışında harita boş başlar – kullanıcı A ve B noktalarını seçmeli
            updateStepInfo('Haritada 2 noktaya tıklayarak İHA rotası oluşturun, sonra ▶ Başlat\'a tıklayın.');
            updateWizard(0);
            // Slider'ları başlangıç durumuna göre güncelle
            updateEnvSliders();
            updateEnvSlidersVS();
        }

        /* =====================================================
           MAP RENDERING
           ===================================================== */
        function clearAllMapLayers() {
            activeLayersSingle.forEach(l => mapSingle.removeLayer(l));
            activeLayersSingle = [];
            activeLayersLeft.forEach(l => mapLeft.removeLayer(l));
            activeLayersLeft = [];
            activeLayersRight.forEach(l => mapRight.removeLayer(l));
            activeLayersRight = [];
        }

        function drawStartMarkerOnly(lat, lng) {
            const addMarker = (map, arr, color) => {
                const m = L.marker([lat, lng], {
                    icon: createCustomIcon('Kalkış Noktası (A)', 'start', color),
                    interactive: false
                }).addTo(map);
                arr.push(m);
            };
            addMarker(mapSingle, activeLayersSingle, 'var(--accent-cyan)');
            addMarker(mapLeft, activeLayersLeft, 'var(--accent-cyan)');
            addMarker(mapRight, activeLayersRight, 'var(--accent-cyan)');
        }

        function renderAllGraphs() {
            clearAllMapLayers();
            drawGraphOnMap(mapSingle, activeLayersSingle, markersSingle, polylinesSingle, weightMarkersSingle, 'var(--accent-cyan)');
            drawGraphOnMap(mapLeft, activeLayersLeft, markersLeft, polylinesLeft, weightMarkersLeft, '#ef4444');
            drawGraphOnMap(mapRight, activeLayersRight, markersRight, polylinesRight, weightMarkersRight, 'var(--accent-green)');
        }

        function drawGraphOnMap(map, layersArray, markersObj, polylinesObj, weightMarkersObj, accentColor) {
            for (const k in markersObj) delete markersObj[k];
            for (const k in polylinesObj) delete polylinesObj[k];
            for (const k in weightMarkersObj) delete weightMarkersObj[k];

            // Draw edges
            edges.forEach(edge => {
                const cA = nodeCoordinates[edge.u];
                const cB = nodeCoordinates[edge.v];
                const key = getEdgeKey(edge.u, edge.v);

                // Use the loaded street geometry if available, otherwise draw straight line first
                const pathPoints = edgeGeometries[key] || [cA, cB];

                // Eğer deniz geçişi kenarı ise (Sea içeriyorsa), deniz rotası stili uygula
                const isSeaEdge = edge.u.startsWith('Sea') || edge.v.startsWith('Sea');
                const lineColor = isSeaEdge ? 'var(--accent-cyan)' : '#1e2f5c';
                const lineWidth = isSeaEdge ? 3 : 2;
                const lineDash = isSeaEdge ? '6, 6' : '4, 4';
                const lineOpacity = isSeaEdge ? 0.95 : 0.8;

                const polyline = L.polyline(pathPoints, {
                    color: lineColor, weight: lineWidth, opacity: lineOpacity, dashArray: lineDash
                }).addTo(map);
                layersArray.push(polyline);
                polylinesObj[key] = polyline;

                const midCoord = pathPoints[Math.floor(pathPoints.length / 2)];
                const badge = L.marker(midCoord, { icon: createWeightIcon(edge.w), interactive: false }).addTo(map);
                layersArray.push(badge);
                weightMarkersObj[key] = badge;
            });

            // Draw nodes
            for (const key in nodeCoordinates) {
                const coords = nodeCoordinates[key];
                let status = 'default';
                if (key === 'A') status = 'start';
                else if (key === 'B') status = 'end';

                const m = L.marker(coords, {
                    icon: createCustomIcon(getNodeLabel(key), status, accentColor),
                    interactive: false
                }).addTo(map);
                layersArray.push(m);
                markersObj[key] = m;
            }
        }

        function fitMapBounds() {
            const cA = nodeCoordinates['A'];
            const cB = nodeCoordinates['B'];
            if (!cA || !cB) return;
            const bounds = L.latLngBounds([cA, cB]);
            const padVal = window.innerWidth <= 768 ? 30 : 80;
            if (activeMode === 'single') {
                mapSingle.fitBounds(bounds, { padding: [padVal, padVal], maxZoom: 18 });
            } else {
                mapLeft.fitBounds(bounds, { padding: [padVal, padVal], maxZoom: 18 });
                mapRight.fitBounds(bounds, { padding: [padVal, padVal], maxZoom: 18 });
            }
        }

        /* =====================================================
           SOLARGRAF – HAVA DURUMU (OPEN-METEO API) ENTEGRASYONU
           ===================================================== */
        async function fetchLiveWeather(lat, lng) {
            const statusElSingle = document.getElementById('weather-status-text');
            const statusElVS = document.getElementById('weather-status-text-vs');
            
            const msg = '🔄 Hava durumu yükleniyor...';
            if (statusElSingle) {
                statusElSingle.textContent = msg;
                statusElSingle.style.color = 'var(--accent-cyan)';
            }
            if (statusElVS) {
                statusElVS.textContent = msg;
                statusElVS.style.color = 'var(--accent-cyan)';
            }
            
            // Open-Meteo API URL - Sıcaklık ve rüzgar hızı (knot cinsinden)
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,wind_speed_10m&wind_speed_unit=kn`;
            try {
                const response = await fetch(url);
                if (!response.ok) throw new Error('API yanıt vermedi');
                const data = await response.json();
                if (data && data.current) {
                    const temp = Math.round(data.current.temperature_2m);
                    const wind = Math.round(data.current.wind_speed_10m);
                    
                    // Arayüzdeki slider değerlerini güncelle
                    const tempSlider = document.getElementById('temp-slider');
                    const windSlider = document.getElementById('wind-slider');
                    if (tempSlider) tempSlider.value = Math.max(0, Math.min(50, temp));
                    if (windSlider) windSlider.value = Math.max(0, Math.min(30, wind));
                    
                    const tempSliderVS = document.getElementById('temp-slider-vs');
                    const windSliderVS = document.getElementById('wind-slider-vs');
                    if (tempSliderVS) tempSliderVS.value = Math.max(0, Math.min(50, temp));
                    if (windSliderVS) windSliderVS.value = Math.max(0, Math.min(30, wind));
                    
                    const now = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                    const statusText = `🟢 Canlı Veri (${now}) | ${temp}°C, ${wind} kn`;
                    
                    if (statusElSingle) {
                        statusElSingle.textContent = statusText;
                        statusElSingle.style.color = 'var(--accent-green)';
                    }
                    if (statusElVS) {
                        statusElVS.textContent = statusText;
                        statusElVS.style.color = 'var(--accent-green)';
                    }
                    
                    toast(`🌐 Canlı Hava Durumu Eşitlendi: ${temp}°C, ${wind} Knot`);
                    
                    // Çevresel koşul göstergelerini ve bar verilerini tetikle
                    updateEnvSliders();
                    updateEnvSlidersVS();
                    return true;
                }
            } catch (error) {
                console.error("Open-Meteo API Error: ", error);
                const errMsg = '❌ API Bağlantı Hatası';
                if (statusElSingle) {
                    statusElSingle.textContent = errMsg;
                    statusElSingle.style.color = 'var(--accent-red)';
                }
                if (statusElVS) {
                    statusElVS.textContent = errMsg;
                    statusElVS.style.color = 'var(--accent-red)';
                }
                toast("⚠️ Hava durumu API bağlantısı başarısız!");
            }
            return false;
        }

        async function fetchLiveWeatherForCurrentCoords(isVS = false) {
            const coords = startNodeCoords || nodeCoordinates['A'];
            if (!coords) {
                toast("⚠️ Önce haritada Kalkış Noktası (A) seçmelisiniz!");
                return;
            }
            await fetchLiveWeather(coords[0], coords[1]);
        }

        /* =====================================================
           SOLARGRAF – ÇEVRESEL KOŞUL PARAMETRELERİ
           ===================================================== */

        // Çevresel durum nesnesi - slider'lardan güncellenir
        let solarEnv = {
            temperature: 25,   // °C
            windKnots: 5,      // knot
            timeOfDay: 'noon', // morning | noon | evening
            panelEfficiency: 1.0, // 0.0–1.0
            solarGain: 1.0,       // 0.0–1.0 güneşlenme oranı
            windFactor: 1.0       // rüzgar maliyet çarpanı
        };

        function computeSolarEnv(temperature, windKnots, timeOfDay) {
            // Güneşlenme oranı (güneş enerjisi kazanımı)
            let solarGain;
            if (timeOfDay === 'noon') {
                solarGain = 1.0;   // Maksimum güneş
            } else if (timeOfDay === 'morning') {
                solarGain = 0.55;  // Sabah orta güneş
            } else {
                solarGain = 0.0;   // Akşam sıfır kazanım
            }

            // Panel verimi: 25°C üzerinde her derece için %0.4 termal kayıp (polikristal Si)
            let panelEfficiency = 1.0;
            if (temperature > 35) {
                // Güneydoğu Anadolu yüksek yaz sıcaklıkları → termal kayıp simülasyonu
                const thermalLoss = (temperature - 35) * 0.012; // ~%1.2/°C kayıp (35°C üzeri)
                panelEfficiency = Math.max(0.45, 1.0 - thermalLoss);
            }

            // Rüzgar katsayısı: rüzgar İHA'nın enerji tüketimini artırır
            // 0–10 knot: minimal etki, 10–20: orta, 20–30: ciddi direnç
            let windFactor;
            if (windKnots <= 10) {
                windFactor = 1.0 + windKnots * 0.01;     // max +%10
            } else if (windKnots <= 20) {
                windFactor = 1.1 + (windKnots - 10) * 0.025; // +%25'e kadar
            } else {
                windFactor = 1.35 + (windKnots - 20) * 0.04; // +%55'e kadar (30 kn = 1.75x)
            }

            return { solarGain, panelEfficiency, windFactor };
        }

        function getSolarEnvParams(isVS = false) {
            if (isVS) {
                const temp = parseInt(document.getElementById('temp-slider-vs')?.value || 25);
                const wind = parseInt(document.getElementById('wind-slider-vs')?.value || 5);
                const tod = document.getElementById('time-of-day-select-vs')?.value || 'noon';
                return { temperature: temp, windKnots: wind, timeOfDay: tod, ...computeSolarEnv(temp, wind, tod) };
            }
            const temp = parseInt(document.getElementById('temp-slider')?.value || 25);
            const wind = parseInt(document.getElementById('wind-slider')?.value || 5);
            const tod = document.getElementById('time-of-day-select')?.value || 'noon';
            return { temperature: temp, windKnots: wind, timeOfDay: tod, ...computeSolarEnv(temp, wind, tod) };
        }

        // SOLARGRAF yeşil maliyet fonksiyonu:
        // Maliyet = (Mesafe * Rüzgar_Katsayısı) - (Güneşlenme_Oranı * Panel_Verimi * Mesafe * 0.3)
        // Net enerji tüketimi = ham maliyet - güneş enerjisi kazanımı
        function solarCost(baseWeight, env) {
            const windPenalty = baseWeight * env.windFactor;
            const solarGainBack = baseWeight * env.solarGain * env.panelEfficiency * 0.3;
            return Math.max(1, Math.round(windPenalty - solarGainBack));
        }

        // Klasik maliyet (sadece mesafe – çevresel faktör yok)
        function classicCost(baseWeight) {
            return baseWeight;
        }

        // Kuş Uçuşu (+200m) yüksek irtifa maliyet fonksiyonu:
        // +200m irtifada rüzgar hızı 1.5x daha şiddetlidir (wind shear).
        // Ancak yeryüzü engelleri (binalar, ağaçlar) olmadığı için güneşlenme kazanımı %20 artar.
        function directAirCost(baseWeight, env) {
            const altitudeWindKnots = env.windKnots * 1.5;
            let windFactor;
            if (altitudeWindKnots <= 10) {
                windFactor = 1.0 + altitudeWindKnots * 0.01;
            } else if (altitudeWindKnots <= 20) {
                windFactor = 1.1 + (altitudeWindKnots - 10) * 0.025;
            } else {
                windFactor = 1.35 + (altitudeWindKnots - 20) * 0.04;
            }
            const windPenalty = baseWeight * windFactor;
            const solarGainBack = baseWeight * Math.min(1.0, env.solarGain * 1.2) * env.panelEfficiency * 0.35;
            return Math.max(1, Math.round(windPenalty - solarGainBack));
        }

        // Güncelleme fonksiyonları - slider/select değişince çalışır
        function updateEnvSliders() {
            const env = getSolarEnvParams(false);
            // Etiket güncelle
            document.getElementById('temp-val').textContent = env.temperature + '°C';
            document.getElementById('wind-val').textContent = env.windKnots + ' knot';
            const todLabels = { morning: 'Sabah 🌅', noon: 'Öğle ☀️', evening: 'Akşam 🌇' };
            document.getElementById('time-of-day-val').textContent = todLabels[env.timeOfDay] || 'Öğle ☀️';

            // Sıcaklık uyarısı
            const tempWarn = document.getElementById('temp-warn');
            if (tempWarn) {
                if (env.temperature > 35) {
                    tempWarn.textContent = '⚠ Termal Kayıp!';
                } else if (env.temperature < 5) {
                    tempWarn.textContent = '❄ Düşük Verim';
                } else {
                    tempWarn.textContent = '';
                }
            }

            // Rüzgar uyarısı
            const windWarn = document.getElementById('wind-warn');
            if (windWarn) {
                if (env.windKnots > 20) {
                    windWarn.textContent = '🌬 Yüksek Direnç!';
                } else if (env.windKnots > 12) {
                    windWarn.textContent = '💨 Orta Rüzgar';
                } else {
                    windWarn.textContent = '';
                }
            }

            // Panel verimi çubuğu
            const effPct = Math.round(env.panelEfficiency * 100);
            const effBar = document.getElementById('panel-eff-bar');
            if (effBar) {
                effBar.style.width = effPct + '%';
                if (effPct < 60) {
                    effBar.style.background = 'linear-gradient(90deg, #ef4444, #f97316)';
                } else if (effPct < 80) {
                    effBar.style.background = 'linear-gradient(90deg, #f59e0b, #84cc16)';
                } else {
                    effBar.style.background = 'linear-gradient(90deg, #10b981, #84cc16)';
                }
            }
            const effVal = document.getElementById('panel-eff-val');
            if (effVal) effVal.textContent = effPct + '%';

            // Sebep metni
            const reasons = [];
            if (env.timeOfDay === 'evening') reasons.push('Güneş enerjisi yok');
            else if (env.timeOfDay === 'morning') reasons.push('Kısmi güneş enerjisi');
            else reasons.push('Tam güneş enerjisi');
            if (env.temperature > 35) reasons.push(`${env.temperature}°C termal kayıp`);
            if (env.windKnots > 12) reasons.push(`${env.windKnots} kn rüzgar direnci`);
            const reasonEl = document.getElementById('solar-reason');
            if (reasonEl) reasonEl.textContent = reasons.join(' · ');

            // Kenar ağırlıklarını yeniden hesapla ve önizlemeyi güncelle
            recomputeSolarGraphWeights(false);
            drawSelectedRoutePreview();
        }

        function updateEnvSlidersVS() {
            const env = getSolarEnvParams(true);
            const tempEl = document.getElementById('temp-val-vs');
            if (tempEl) tempEl.textContent = env.temperature + '°C';
            const windEl = document.getElementById('wind-val-vs');
            if (windEl) windEl.textContent = env.windKnots + ' knot';
            const todLabels = { morning: 'Sabah 🌅', noon: 'Öğle ☀️', evening: 'Akşam 🌇' };
            const todEl = document.getElementById('time-of-day-val-vs');
            if (todEl) todEl.textContent = todLabels[env.timeOfDay] || 'Öğle ☀️';

            const tempWarnVS = document.getElementById('temp-warn-vs');
            if (tempWarnVS) {
                tempWarnVS.textContent = env.temperature > 35 ? '⚠ Termal Kayıp!' : env.temperature < 5 ? '❄ Düşük Verim' : '';
            }
            const windWarnVS = document.getElementById('wind-warn-vs');
            if (windWarnVS) {
                windWarnVS.textContent = env.windKnots > 20 ? '🌬 Yüksek Direnç!' : env.windKnots > 12 ? '💨 Orta Rüzgar' : '';
            }

            const effPct = Math.round(env.panelEfficiency * 100);
            const effBarVS = document.getElementById('panel-eff-bar-vs');
            if (effBarVS) {
                effBarVS.style.width = effPct + '%';
                effBarVS.style.background = effPct < 60
                    ? 'linear-gradient(90deg, #ef4444, #f97316)'
                    : effPct < 80
                        ? 'linear-gradient(90deg, #f59e0b, #84cc16)'
                        : 'linear-gradient(90deg, #10b981, #84cc16)';
            }
            const effValVS = document.getElementById('panel-eff-val-vs');
            if (effValVS) effValVS.textContent = effPct + '%';
            const reasonElVS = document.getElementById('solar-reason-vs');
            if (reasonElVS) {
                const reasons = [];
                if (env.timeOfDay === 'evening') reasons.push('Güneş enerjisi yok');
                else if (env.timeOfDay === 'morning') reasons.push('Kısmi güneş');
                else reasons.push('Tam güneş');
                if (env.temperature > 35) reasons.push(`${env.temperature}°C termal kayıp`);
                reasonElVS.textContent = reasons.join(' · ');
            }
            drawSelectedRoutePreview();
        }

        // Çevresel koşullar değişince solar graph ağırlıklarını yeniden hesapla
        function recomputeSolarGraphWeights(isVS) {
            if (!edges || edges.length === 0) return;
            const env = getSolarEnvParams(isVS);
            // graph'ı yeniden oluştur – edges.w zaten ham mesafe bazlı
            // solar cost fonksiyonu her algoritma çalışmasında uygulanır (runAlgo içinde)
            // Bu fonksiyon graph'ı mevcut env ile günceller
            graph = {};
            const allKeys = Object.keys(nodeCoordinates);
            allKeys.forEach(k => graph[k] = []);
            edges.forEach(edge => {
                // Her kenar için iki versiyon tutarız: ham w + solar modifiye
                graph[edge.u].push({ target: edge.v, weight: edge.w, solarWeight: solarCost(edge.w, env) });
                graph[edge.v].push({ target: edge.u, weight: edge.w, solarWeight: solarCost(edge.w, env) });
            });
        }

        // Simülasyon tamamlandıktan sonra telemetri hesapla
        function computeTelemetry(result, env, isClassic) {
            if (!result.success) return { battery: '—', panelTemp: '—', co2: '—' };

            // Batarya: temel batarya kapasitesi 10000 birim, maliyet başına tüketim
            const baseBattery = 10000;
            const consumed = isClassic
                ? result.cost                             // klasik: sadece ham maliyet
                : result.cost * (2 - env.panelEfficiency * env.solarGain * 0.5); // solar: daha az tüketim
            const batteryPct = Math.max(5, Math.round(100 - (consumed / baseBattery) * 100));

            // Panel sıcaklığı: hava sıcaklığı + dron ısı etkisi (hareket ısınması)
            const droneThermal = isClassic ? 0 : 5; // SOLARGRAF daha verimli, daha az ısınır
            const panelTemp = Math.round(env.temperature + 15 + droneThermal + (env.windKnots > 15 ? -3 : 0));

            // CO2 tasarrufu: klasikle kıyasla (%0 tasarruf) vs yeşil (%15–45 arası)
            const co2Saving = isClassic
                ? '0 kg (baz)'
                : (() => {
                    const saving = Math.round((env.solarGain * env.panelEfficiency * 0.45 + 0.1) * 100);
                    return `≈${Math.min(saving, 50)}% az CO₂`;
                })();

            return { battery: batteryPct + '%', panelTemp: panelTemp + '°C', co2: co2Saving };
        }

        /* =====================================================
           ALGORITHMS
           ===================================================== */
        function runDijkstra(start, end, useSolarCost = false) {
            const startTime = performance.now();
            const dist = {}, parent = {}, steps = [], visitedOrder = [];
            for (const node in nodeCoordinates) { dist[node] = Infinity; parent[node] = null; }
            dist[start] = 0;
            const unvisited = new Set(Object.keys(nodeCoordinates));

            while (unvisited.size > 0) {
                let curr = null, minDist = Infinity;
                for (const node of unvisited) {
                    if (dist[node] < minDist) { minDist = dist[node]; curr = node; }
                }
                if (curr === null || curr === end) {
                    if (curr === end) { visitedOrder.push(curr); steps.push({ type: 'visit', node: curr, parent: parent[curr] }); }
                    break;
                }
                unvisited.delete(curr);
                visitedOrder.push(curr);
                steps.push({ type: 'visit', node: curr, parent: parent[curr] });
                for (const edge of (graph[curr] || [])) {
                    const { target } = edge;
                    const weight = useSolarCost ? (edge.solarWeight || edge.weight) : edge.weight;
                    if (unvisited.has(target)) {
                        const alt = dist[curr] + weight;
                        steps.push({ type: 'relax', from: curr, to: target, weight });
                        if (alt < dist[target]) { dist[target] = alt; parent[target] = curr; }
                    }
                }
            }
            const path = [];
            if (dist[end] !== Infinity) { let c = end; while (c !== null) { path.unshift(c); c = parent[c]; } }
            return { success: dist[end] !== Infinity, path, visited: visitedOrder, steps, cost: dist[end] === Infinity ? 0 : dist[end], hops: path.length > 0 ? path.length - 1 : 0, time: (performance.now() - startTime).toFixed(4) };
        }

        function runAStar(start, end, useSolarCost = false) {
            const startTime = performance.now();
            const gScore = {}, fScore = {}, parent = {}, steps = [], visitedOrder = [];
            for (const node in nodeCoordinates) { gScore[node] = Infinity; fScore[node] = Infinity; parent[node] = null; }
            gScore[start] = 0;
            fScore[start] = getHeuristicDistance(start, end);
            const openSet = new Set([start]);
            const closedSet = new Set();

            while (openSet.size > 0) {
                let curr = null, minF = Infinity;
                for (const node of openSet) { if (fScore[node] < minF) { minF = fScore[node]; curr = node; } }
                if (curr === end) { visitedOrder.push(curr); steps.push({ type: 'visit', node: curr, parent: parent[curr] }); break; }
                openSet.delete(curr);
                closedSet.add(curr);
                visitedOrder.push(curr);
                steps.push({ type: 'visit', node: curr, parent: parent[curr] });
                for (const edge of (graph[curr] || [])) {
                    const { target } = edge;
                    const weight = useSolarCost ? (edge.solarWeight || edge.weight) : edge.weight;
                    if (closedSet.has(target)) continue;
                    const tentativeG = gScore[curr] + weight;
                    steps.push({ type: 'relax', from: curr, to: target, weight });
                    if (!openSet.has(target)) openSet.add(target);
                    else if (tentativeG >= gScore[target]) continue;
                    parent[target] = curr;
                    gScore[target] = tentativeG;
                    fScore[target] = tentativeG + getHeuristicDistance(target, end);
                }
            }
            const path = [];
            if (gScore[end] !== Infinity) { let c = end; while (c !== null) { path.unshift(c); c = parent[c]; } }
            return { success: gScore[end] !== Infinity, path, visited: visitedOrder, steps, cost: gScore[end] === Infinity ? 0 : gScore[end], hops: path.length > 0 ? path.length - 1 : 0, time: (performance.now() - startTime).toFixed(4) };
        }

        function runBFS(start, end, useSolarCost = false) {
            const startTime = performance.now();
            const parent = {}, steps = [], visitedOrder = [];
            for (const node in nodeCoordinates) parent[node] = null;
            const queue = [start];
            const visited = new Set([start]);
            let found = false;

            while (queue.length > 0) {
                const curr = queue.shift();
                visitedOrder.push(curr);
                steps.push({ type: 'visit', node: curr, parent: parent[curr] });
                if (curr === end) { found = true; break; }
                for (const { target } of (graph[curr] || [])) {
                    if (!visited.has(target)) {
                        visited.add(target);
                        parent[target] = curr;
                        steps.push({ type: 'relax', from: curr, to: target });
                        queue.push(target);
                    }
                }
            }
            const path = [];
            let cost = 0;
            if (found) {
                let c = end; while (c !== null) { path.unshift(c); c = parent[c]; }
                for (let i = 0; i < path.length - 1; i++) {
                    const edge = edges.find(e => getEdgeKey(e.u, e.v) === getEdgeKey(path[i], path[i + 1]));
                    if (edge) {
                        cost += useSolarCost
                            ? solarCost(edge.w, getSolarEnvParams(activeMode === 'vs'))
                            : edge.w;
                    }
                }
            }
            return { success: found, path, visited: visitedOrder, steps, cost, hops: path.length > 0 ? path.length - 1 : 0, time: (performance.now() - startTime).toFixed(4) };
        }

        function runDirect(start, end, useSolarCost = false) {
            const startTime = performance.now();
            const path = [start, end];
            // Kuş uçuşu mesafeye karşılık gelen temel ağırlık
            const baseWeight = Math.max(5, Math.round(getHeuristicDistance(start, end)));
            const env = getSolarEnvParams(activeMode === 'vs');
            const cost = useSolarCost ? directAirCost(baseWeight, env) : baseWeight;
            const steps = [
                { type: 'visit', node: start, parent: null },
                { type: 'visit', node: end, parent: start }
            ];
            return {
                success: true,
                path,
                visited: [start, end],
                steps,
                cost,
                hops: 1,
                time: (performance.now() - startTime).toFixed(4)
            };
        }

        function runAlgo(name, start, end, useSolarCost = false) {
            switch (name) {
                case 'dijkstra': return runDijkstra(start, end, useSolarCost);
                case 'astar': return runAStar(start, end, useSolarCost);
                case 'bfs': return runBFS(start, end, useSolarCost);
                case 'direct': return runDirect(start, end, useSolarCost);
            }
        }

        /* =====================================================
           ANIMATION ENGINE
           ===================================================== */
        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        async function startVisualizer() {
            if (isAnimating) return;
            if (!nodeCoordinates['A'] || !nodeCoordinates['B']) {
                toast("⚠️ Önce haritada A ve B noktalarını seçin!");
                return;
            }

            // Clear map search animations & stats, but keep graph nodes
            renderAllGraphs();
            clearStats();
            clearVSStats();

            isAnimating = true;
            document.getElementById('btn-run').disabled = true;
            document.getElementById('btn-run').style.opacity = '0.5';
            const fabEl = document.getElementById('fab');
            if (fabEl) { fabEl.disabled = true; fabEl.style.opacity = '0.5'; }
            setProgress(5);
            updateWizard(3);

            // Auto-close sidebar on mobile to view animation immediately
            if (window.innerWidth <= 768) {
                const sb = document.getElementById('sidebar');
                const ov = document.getElementById('sidebar-overlay');
                const btn = document.getElementById('menu-toggle');
                if (sb.classList.contains('open')) {
                    sb.classList.remove('open');
                    ov.classList.remove('show');
                    if (btn) btn.textContent = '☰';
                }
            }

            const animId = ++currentAnimationId;

            if (activeMode === 'single') {
                recomputeSolarGraphWeights(false);
                const result = runAlgo(selectedAlgo, 'A', 'B', true); // single mode = yeşil solar
                await animateSingleMode(result, animId);
            } else {
                recomputeSolarGraphWeights(true);
                const algoLeft = document.getElementById('vs-algo-a').value;
                const algoRight = document.getElementById('vs-algo-b').value;
                const resultLeft = runAlgo(algoLeft, 'A', 'B', false);  // Klasik rota: solar yok
                const resultRight = runAlgo(algoRight, 'A', 'B', true); // SOLARGRAF Yeşil rota
                await animateVsMode(resultLeft, resultRight, algoLeft, algoRight, animId);
            }

            isAnimating = false;
            document.getElementById('btn-run').disabled = false;
            document.getElementById('btn-run').style.opacity = '1';
            const fabEl2 = document.getElementById('fab');
            if (fabEl2) { fabEl2.disabled = false; fabEl2.style.opacity = '1'; }
            setProgress(100);
            updateWizard(4);
            setTimeout(resetProgress, 1200);
            toast('🌿 SOLARGRAF Yeşil İHA simülasyonu başarıyla tamamlandı!');
        }

        async function animateSingleMode(result, animId) {
            const totalSteps = result.steps.length;
            let visitedCount = 0;
            for (let i = 0; i < result.steps.length; i++) {
                if (currentAnimationId !== animId) return;
                const step = result.steps[i];

                if (step.type === 'visit') {
                    visitedCount++;
                    const m = markersSingle[step.node];
                    if (step.node !== 'A' && step.node !== 'B' && m) {
                        // Önceki "aktif taranan" düğümü ziyaret edildi rengiyle işaretle
                        if (window._prevActiveSingleNode && window._prevActiveSingleNode !== step.node) {
                            const pm = markersSingle[window._prevActiveSingleNode];
                            if (pm) pm.setIcon(createCustomIcon(getNodeLabel(window._prevActiveSingleNode), 'visited', 'var(--accent-yellow)'));
                        }
                        // Şu an taranan düğümü parlak/büyük ikon ile göster
                        m.setIcon(createCurrentScanIcon(getNodeLabel(step.node)));
                        window._prevActiveSingleNode = step.node;
                    }
                    if (step.parent) {
                        const ek = getEdgeKey(step.parent, step.node);
                        if (polylinesSingle[ek]) {
                            polylinesSingle[ek].setStyle({ color: '#f59e0b', weight: 4, opacity: 1.0, dashArray: null });
                        }
                    }
                    updateStatEl('stat-visited', `${visitedCount} / ${Object.keys(nodeCoordinates).length}`);
                    updateStepInfo(`🔍 Taranan: ${getNodeLabel(step.node)}`);
                    setProgress(5 + Math.round((i / totalSteps) * 80));
                    await sleep(animationDelay);
                } else if (step.type === 'relax') {
                    const ek = getEdgeKey(step.from, step.to);
                    const pl = polylinesSingle[ek];
                    if (pl) {
                        const origColor = pl.options.color;
                        pl.setStyle({ color: 'var(--accent-cyan)', weight: 3, opacity: 0.8 });
                        await sleep(animationDelay / 3);
                        if (origColor !== '#f59e0b') pl.setStyle({ color: origColor, weight: 2, opacity: 0.8 });
                    }
                }
            }

            // Final path
            if (result.success && result.path.length > 0) {
                clearHighlightedRoutes();
                const allPathCoords = [];
                for (let i = 0; i < result.path.length - 1; i++) {
                    const u = result.path[i], v = result.path[i + 1];
                    const key = getEdgeKey(u, v);
                    const geom = edgeGeometries[key] || [nodeCoordinates[u], nodeCoordinates[v]];
                    if (i === 0) {
                        allPathCoords.push(...geom);
                    } else {
                        allPathCoords.push(...geom.slice(1));
                    }
                }

                if (allPathCoords.length > 0) {
                    const coordsDraw = [allPathCoords[0]];
                    pathPolylineSingle = L.polyline(coordsDraw, {
                        color: 'var(--accent-green)',  // SOLARGRAF Yeşil
                        weight: 10,
                        opacity: 0.95
                    }).addTo(mapSingle);

                    const pointDelay = Math.max(5, Math.min(25, Math.round(1500 / allPathCoords.length)));
                    const passedNodes = new Set();

                    for (let k = 1; k < allPathCoords.length; k++) {
                        if (currentAnimationId !== animId) return;
                        coordsDraw.push(allPathCoords[k]);
                        pathPolylineSingle.setLatLngs(coordsDraw);

                        result.path.forEach(v => {
                            if (v !== 'A' && v !== 'B' && !passedNodes.has(v)) {
                                const nodeCoord = nodeCoordinates[v];
                                const dist = getGeographicalDistance(allPathCoords[k], nodeCoord) * 1000;
                                if (dist < 20) {
                                    passedNodes.add(v);
                                    if (markersSingle[v]) {
                                        markersSingle[v].setIcon(createCustomIcon(getNodeLabel(v), 'path', 'var(--accent-green)'));
                                    }
                                }
                            }
                        });

                        await sleep(pointDelay);
                    }
                }

                result.path.forEach(v => {
                    if (v !== 'A' && v !== 'B' && markersSingle[v]) {
                        markersSingle[v].setIcon(createCustomIcon(getNodeLabel(v), 'path', 'var(--accent-green)'));
                    }
                });
            }

            const env = getSolarEnvParams(false);
            const telemetry = computeTelemetry(result, env, false); // single mode = yeşil

            updateStatEl('stat-battery', telemetry.battery);
            updateStatEl('stat-panel-temp', telemetry.panelTemp);
            updateStatEl('stat-co2', telemetry.co2);
            updateStatEl('stat-time', `${result.time} ms`);
            updateStepInfo(result.success
                ? `✅ Yeşil İHA rotası tamamlandı! Batarya: ${telemetry.battery} | CO₂: ${telemetry.co2}`
                : '❌ Varış Noktası (B) ulaşılamaz durumda!');
        }

        async function animateVsMode(resultL, resultR, algoLKey, algoRKey, animId) {
            let idxL = 0, idxR = 0, visitedCountL = 0, visitedCountR = 0;
            const maxSteps = Math.max(resultL.steps.length, resultR.steps.length);

            for (let i = 0; i < maxSteps; i++) {
                if (currentAnimationId !== animId) return;

                if (idxL < resultL.steps.length) {
                    const step = resultL.steps[idxL];
                    if (step.type === 'visit') {
                        visitedCountL++;
                        const m = markersLeft[step.node];
                        if (step.node !== 'A' && step.node !== 'B' && m) m.setIcon(createCustomIcon(getNodeLabel(step.node), 'visited', '#ef4444'));
                        if (step.parent) { const ek = getEdgeKey(step.parent, step.node); if (polylinesLeft[ek]) polylinesLeft[ek].setStyle({ color: '#ef4444', weight: 3, opacity: 0.9, dashArray: null }); }
                    }
                    idxL++;
                }

                if (idxR < resultR.steps.length) {
                    const step = resultR.steps[idxR];
                    if (step.type === 'visit') {
                        visitedCountR++;
                        const m = markersRight[step.node];
                        if (step.node !== 'A' && step.node !== 'B' && m) m.setIcon(createCustomIcon(getNodeLabel(step.node), 'visited', 'var(--accent-green)'));
                        if (step.parent) { const ek = getEdgeKey(step.parent, step.node); if (polylinesRight[ek]) polylinesRight[ek].setStyle({ color: 'var(--accent-green)', weight: 3, opacity: 0.9, dashArray: null }); }
                    }
                    idxR++;
                }

                updateStatEl('vs-val-visited-a', `${visitedCountL} sokak`);
                updateStatEl('vs-val-visited-b', `${visitedCountR} sokak`);
                await sleep(animationDelay);
            }

            // Final paths
            clearHighlightedRoutes();

            const allCoordsL = [];
            if (resultL.success) {
                for (let i = 0; i < resultL.path.length - 1; i++) {
                    const u = resultL.path[i], v = resultL.path[i + 1];
                    const key = getEdgeKey(u, v);
                    const geom = edgeGeometries[key] || [nodeCoordinates[u], nodeCoordinates[v]];
                    if (i === 0) allCoordsL.push(...geom);
                    else allCoordsL.push(...geom.slice(1));
                }
            }

            const allCoordsR = [];
            if (resultR.success) {
                for (let i = 0; i < resultR.path.length - 1; i++) {
                    const u = resultR.path[i], v = resultR.path[i + 1];
                    const key = getEdgeKey(u, v);
                    const geom = edgeGeometries[key] || [nodeCoordinates[u], nodeCoordinates[v]];
                    if (i === 0) allCoordsR.push(...geom);
                    else allCoordsR.push(...geom.slice(1));
                }
            }

            const maxLength = Math.max(allCoordsL.length, allCoordsR.length);
            if (maxLength > 0) {
                const drawCoordsL = [];
                const drawCoordsR = [];

                if (resultL.success && allCoordsL.length > 0) {
                    drawCoordsL.push(allCoordsL[0]);
                    pathPolylineLeft = L.polyline(drawCoordsL, {
                        color: '#ef4444',   // Klasik rota – KIRMIZI
                        weight: 10,
                        opacity: 0.95
                    }).addTo(mapLeft);
                }

                if (resultR.success && allCoordsR.length > 0) {
                    drawCoordsR.push(allCoordsR[0]);
                    pathPolylineRight = L.polyline(drawCoordsR, {
                        color: 'var(--accent-green)',  // SOLARGRAF Yeşil Rotası
                        weight: 10,
                        opacity: 0.95
                    }).addTo(mapRight);
                }

                const pointDelay = Math.max(5, Math.min(25, Math.round(1500 / maxLength)));
                const passedNodesL = new Set();
                const passedNodesR = new Set();

                for (let k = 1; k < maxLength; k++) {
                    if (currentAnimationId !== animId) return;

                    if (resultL.success && k < allCoordsL.length) {
                        drawCoordsL.push(allCoordsL[k]);
                        pathPolylineLeft.setLatLngs(drawCoordsL);

                        resultL.path.forEach(v => {
                            if (v !== 'A' && v !== 'B' && !passedNodesL.has(v)) {
                                const nodeCoord = nodeCoordinates[v];
                                const dist = getGeographicalDistance(allCoordsL[k], nodeCoord) * 1000;
                                if (dist < 20) {
                                    passedNodesL.add(v);
                                    if (markersLeft[v]) markersLeft[v].setIcon(createCustomIcon(getNodeLabel(v), 'path', 'var(--accent-green)'));
                                }
                            }
                        });
                    }

                    if (resultR.success && k < allCoordsR.length) {
                        drawCoordsR.push(allCoordsR[k]);
                        pathPolylineRight.setLatLngs(drawCoordsR);

                        resultR.path.forEach(v => {
                            if (v !== 'A' && v !== 'B' && !passedNodesR.has(v)) {
                                const nodeCoord = nodeCoordinates[v];
                                const dist = getGeographicalDistance(allCoordsR[k], nodeCoord) * 1000;
                                if (dist < 20) {
                                    passedNodesR.add(v);
                                    if (markersRight[v]) markersRight[v].setIcon(createCustomIcon(getNodeLabel(v), 'path', 'var(--accent-green)'));
                                }
                            }
                        });
                    }

                    await sleep(pointDelay);
                }

                if (resultL.success) {
                    resultL.path.forEach(v => {
                        if (v !== 'A' && v !== 'B' && markersLeft[v]) {
                            markersLeft[v].setIcon(createCustomIcon(getNodeLabel(v), 'path', 'var(--accent-green)'));
                        }
                    });
                }
                if (resultR.success) {
                    resultR.path.forEach(v => {
                        if (v !== 'A' && v !== 'B' && markersRight[v]) {
                            markersRight[v].setIcon(createCustomIcon(getNodeLabel(v), 'path', 'var(--accent-green)'));
                        }
                    });
                }
            }

            // SOLARGRAF Telemetri – VS Mode
            const vsEnv = getSolarEnvParams(true);
            const telemetryClassic = computeTelemetry(resultL, vsEnv, true);  // Klasik – solar yok
            const telemetrySolar = computeTelemetry(resultR, vsEnv, false);   // SOLARGRAF – yeşil

            updateStatEl('vs-val-battery-a', telemetryClassic.battery);
            updateStatEl('vs-val-co2-a', telemetryClassic.co2);
            updateStatEl('vs-val-battery-b', telemetrySolar.battery);
            updateStatEl('vs-val-co2-b', telemetrySolar.co2);

            // Winner
            const cardA = document.getElementById('vs-card-a');
            const cardB = document.getElementById('vs-card-b');
            const winnerRow = document.getElementById('vs-winner-row');
            const winnerBadge = document.getElementById('vs-winner-badge');

            cardA.classList.remove('winner-card');
            cardB.classList.remove('winner-card');

            let winner = '—', winnerColor = '#94a3b8';
            if (resultL.success && resultR.success) {
                // SOLARGRAF daha az enerji harcıyorsa (düşük maliyet = daha yeşil)
                if (resultR.cost < resultL.cost) {
                    cardB.classList.add('winner-card'); winner = '🟢 SOLARGRAF Yeşil Rotası (Daha Verimli)'; winnerColor = '#10b981';
                } else if (resultL.cost < resultR.cost) {
                    cardA.classList.add('winner-card'); winner = '🔴 Klasik Rota (Bu Koşulda Daha Hızlı)'; winnerColor = '#ef4444';
                } else {
                    winner = 'Eşit Verim – Yeşil Enerji Farkı'; winnerColor = '#f59e0b';
                }
            } else if (resultL.success) {
                cardA.classList.add('winner-card'); winner = '🔴 Klasik Rota'; winnerColor = '#ef4444';
            } else if (resultR.success) {
                cardB.classList.add('winner-card'); winner = '🟢 SOLARGRAF Yeşil Rotası'; winnerColor = '#10b981';
            } else {
                winner = 'İki rota da hedefe ulaşamadı!'; winnerColor = '#ef4444';
            }
            winnerRow.style.display = '';
            winnerBadge.textContent = '🏆 Kazanan: ' + winner;
            winnerBadge.style.color = winnerColor;
        }

        /* =====================================================
           RESET
           ===================================================== */
        function resetVisualizer() {
            currentAnimationId++;
            isAnimating = false;
            document.getElementById('btn-run').disabled = false;
            document.getElementById('btn-run').style.opacity = '1';
            const fabEl = document.getElementById('fab');
            if (fabEl) { fabEl.disabled = false; fabEl.style.opacity = '1'; }

            // Haritadaki bütün noktaları, yolları ve grafikleri tamamen sıfırla
            startNodeCoords = null;
            endNodeCoords = null;
            clickCount = 0;
            nodeCoordinates = {};
            graph = {};
            edges = [];
            edgeGeometries = {};
            nodeStreetNames = {};

            // Harita üzerindeki çizim ve işaretçileri kaldır
            clearAllMapLayers();

            clearStats();
            clearVSStats();

            resetProgress();
            updateWizard(0);

            const canvasLabel = document.getElementById('canvas-label');
            if (canvasLabel) {
                canvasLabel.textContent = '🛸 Haritada tıkla ➔ 1.tık=Kalkış Noktası (A) | 2.tık=Varış Noktası (B) + 3 alternatif İHA güzergahı';
            }
            updateStepInfo('Haritada 2 noktaya tıklayarak İHA rotası oluşturun, sonra ▶ Başlat\'a tıklayın.');
        }

        /* =====================================================
           UI HELPERS
           ===================================================== */
        function setMode(mode) {
            if (isAnimating) return;
            activeMode = mode;

            document.getElementById('tab-single').classList.toggle('active', mode === 'single');
            document.getElementById('tab-vs').classList.toggle('active', mode === 'vs');
            document.getElementById('panel-single').style.display = mode === 'single' ? '' : 'none';
            document.getElementById('panel-vs').style.display = mode === 'vs' ? '' : 'none';

            document.getElementById('map-single').classList.toggle('hidden', mode === 'vs');
            document.getElementById('map-vs-container').classList.toggle('hidden', mode === 'single');

            setTimeout(() => {
                if (mode === 'single') {
                    mapSingle.invalidateSize();
                } else {
                    mapLeft.invalidateSize();
                    mapRight.invalidateSize();
                }
                fitMapBounds();
            }, 100);

            resetVisualizer();
        }
        const ALGO_INFO = {
            dijkstra: { title: 'Dijkstra – Yeşil Enerji Optimizasyonu', desc: 'Rüzgar katsayısı ve fotovoltaik panel verimini dikkate alarak en düşük net enerji harcayan İHA teslimat rotasını garanti eder. Maliyet = (Mesafe × Rüzgar) − (Güneş × Verim).', complexity: '⏱ O(V log V + E) &nbsp;|&nbsp; 💾 O(V)' },
            astar: { title: 'A* – Akıllı Yeşil Yönelim', desc: 'Güneş enerjisi maliyetlerine ek olarak İHA\'nın varış noktasına olan kuş uçuşu mesafesini sezgisel olarak hesaba katarak yeşil enerji rotasını çok daha kısa sürede hesaplar.', complexity: '⏱ O(E log V) &nbsp;|&nbsp; 💾 O(V)' },
            bfs: { title: 'BFS – Minimum Geçiş Noktası', desc: 'Rüzgar ve güneş koşullarını ikinci planda bırakarak en az İHA iniş/kalkış noktasıyla (en az geçişli) düz hat rotasını tespit eder. Acil teslimat senaryolarında kullanılır.', complexity: '⏱ O(V+E) &nbsp;|&nbsp; 💾 O(V)' },
            direct: { title: 'Kuş Uçuşu (+200m) Hava Koridoru', desc: 'Engelsiz hava sahasında doğrudan A\'dan B\'ye uçuş gerçekleştirir. Sokak ağını takip etmez. +200 metre irtifada rüzgar etkisi %50 daha fazladır ancak gölgeleme olmadığı için panel verimi %20 daha yüksektir.', complexity: '⏱ O(1) &nbsp;|&nbsp; 💾 O(1)' },
        };

        function selectAlgo(name, card) {
            selectedAlgo = name;
            document.querySelectorAll('#algo-grid .algo-card').forEach(c => c.classList.remove('selected'));
            if (card) card.classList.add('selected');
            const info = ALGO_INFO[name];
            document.getElementById('algo-info-box').innerHTML = `<div class="info-title">${info.title}</div>${info.desc}<div class="complexity">${info.complexity}</div>`;
            drawSelectedRoutePreview();
        }

        function updateSpeed(val) {
            animationDelay = parseInt(val);
            document.getElementById('speed-label').textContent = val + 'ms';
        }

        function changeMapStyle(styleName) {
            const style = MAP_STYLES[styleName];
            if (!style) return;

            if (tileSingle && mapSingle) {
                mapSingle.removeLayer(tileSingle);
                tileSingle = L.tileLayer(style.url, style.options).addTo(mapSingle);
            }
            if (tileLeft && mapLeft) {
                mapLeft.removeLayer(tileLeft);
                tileLeft = L.tileLayer(style.url, style.options).addTo(mapLeft);
            }
            if (tileRight && mapRight) {
                mapRight.removeLayer(tileRight);
                tileRight = L.tileLayer(style.url, style.options).addTo(mapRight);
            }
            toast(`🗺️ Harita: ${document.getElementById('map-style-select').options[document.getElementById('map-style-select').selectedIndex].text}`);
        }

        function updateStepInfo(msg) {
            const el = document.getElementById('step-info');
            if (el) el.textContent = msg;
        }

        function updateStatEl(id, val) {
            const el = document.getElementById(id);
            if (el) el.textContent = val;
        }

        function clearStats() {
            ['stat-battery', 'stat-panel-temp', 'stat-co2', 'stat-visited', 'stat-time'].forEach(id => updateStatEl(id, '—'));
        }

        function clearVSStats() {
            ['vs-val-battery-a', 'vs-val-co2-a', 'vs-val-visited-a', 'vs-val-battery-b', 'vs-val-co2-b', 'vs-val-visited-b'].forEach(id => updateStatEl(id, '—'));
            const cardA = document.getElementById('vs-card-a');
            const cardB = document.getElementById('vs-card-b');
            if (cardA) cardA.classList.remove('winner-card');
            if (cardB) cardB.classList.remove('winner-card');
            const wr = document.getElementById('vs-winner-row');
            if (wr) wr.style.display = 'none';
        }

        let toastTimer = null;
        function toast(msg) {
            const el = document.getElementById('toast');
            el.textContent = msg;
            el.classList.add('show');
            clearTimeout(toastTimer);
            toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
        }

        function toggleSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebar-overlay');
            const btn = document.getElementById('menu-toggle');
            const open = sb.classList.toggle('open');
            ov.classList.toggle('show', open);
            if (btn) {
                btn.textContent = open ? '✕' : '☰';
            }
        }

        /* =====================================================
           INIT
           ===================================================== */
        window.addEventListener('DOMContentLoaded', async () => {
            await initMaps();
        });
